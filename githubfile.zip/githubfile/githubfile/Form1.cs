﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Octokit;

namespace githubfile
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        public async void addfile()
        {
            var client = new GitHubClient(new ProductHeaderValue("writeanyvalueanything"));
            client.Credentials = new Credentials("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");
            var result = await client.Repository.Content.CreateFile
                ("IT-core-soft", "myfirstfolder", "myfirstfile.txt", new CreateFileRequest("first commit", "here is my content", "main", true));
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            addfile();
        }
    }
}
